﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace TemplateAutomatedTest.Template.Tests
{
    [TestClass()]
    public class TemplateQuestionTests
    {
        public TestContext TestContext { get; set; }
        //start
 //starttest1 public void testcase1 Driver.findViewById("txtUsername").clear();  Driver.findViewById("txtUsername").sendKey("NguyenVanA");  Driver.findViewById("txtPassword").clear();  Driver.findViewById("txtPassword").sendKey("p4ssw0rd");     assertEquals("admin",question1("NguyenVanA","p4ssw0rd"));    //endtest1  
//end
        [TestCleanup]
        public void TestCleanup()
        {
            String testResult = TestContext.CurrentTestOutcome.ToString();
            String testName = TestContext.TestName;
            String result = testName + " : " + testResult;
            String path = @"C:\Users\ADMIN\source\repos\TemplateAutomatedTest\TemplateAutomatedTest\Ultilities\Result.txt";
            Ultilities.TestResult.WriteResult(path,result);
        }
    }
}