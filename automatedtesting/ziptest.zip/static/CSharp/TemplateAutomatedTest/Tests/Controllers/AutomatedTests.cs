﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TemplateAutomatedTest.Controllers;
using System;
using System.Collections.Generic;
using System.Text;
using TemplateAutomatedTest.Template;

namespace AutomatedTests
{
    [TestClass()]
    public class AutomatedTests
    {
        public TestContext TestContext { get; set; }
        //start
        [TestMethod()]
        public void Question1Test()
        {
            Assert.AreEqual(5, TemplateQuestion.Question1(2, 3));
        }
        [TestMethod()]
        public void Question2Test()
        {
            Assert.AreEqual(4, TemplateQuestion.Question2(5, 1));
        }
        //end
        [TestCleanup]
        public void TestCleanup()
        {
            String testResult = TestContext.CurrentTestOutcome.ToString();
            String testName = TestContext.TestName;
            String result = testName + " : " + testResult;
            String path = @"C:\Users\ADMIN\source\repos\TemplateAutomatedTest\TemplateAutomatedTest\Ultilities\Result.txt";
            TemplateAutomatedTest.Ultilities.TestResult.WriteResult(path, result);
        }
    }
}


