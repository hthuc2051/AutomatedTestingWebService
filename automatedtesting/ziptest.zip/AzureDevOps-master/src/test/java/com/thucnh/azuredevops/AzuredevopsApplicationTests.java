package com.thucnh.azuredevops;

import com.thucnh.azuredevops.template.TemplateQuestion;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest
class AzuredevopsApplicationTests {

    @Autowired
    private TemplateQuestion templateQuestion;

  //start //starttest1 public void testcase1 Driver.findViewById('txtUsername').clear();  Driver.findViewById('txtUsername').sendKey('NguyenVanA');  Driver.findViewById('txtPassword').clear();  Driver.findViewById('txtPassword').sendKey('p4ssw0rd');     assertEquals('admin',question1('NguyenVanA','p4ssw0rd'));    //end question1  //end
}