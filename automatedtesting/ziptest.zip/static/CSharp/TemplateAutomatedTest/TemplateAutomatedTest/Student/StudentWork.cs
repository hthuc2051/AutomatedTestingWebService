﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TemplateAutomatedTest.Student
{
    public class StudentWork
    { 
        public static int AddTwoNumber(int number1, int number2)
        {
            return number1 + number2;
        }
        public static int MinusTwoNumber(int number1, int number2)
        {
            return number1 - number2;
        }
    }
}
